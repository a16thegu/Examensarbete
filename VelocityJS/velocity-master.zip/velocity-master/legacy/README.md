This folder contains code that is planned to go into a legacy browser support Javascript file for people targeting older versions of IE.

This is a very low priority process, so there is no ETA (though people stating what parts are needed will help).
