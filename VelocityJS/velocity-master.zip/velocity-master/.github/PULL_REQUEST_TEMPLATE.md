#### Checklist

* Have you linked to relevant open issues?: [Yes/No]
* I agree for this to be covered by the Velocity [license](https://github.com/julianshapiro/velocity/blob/master/LICENSE.md)?: [Yes/No]

#### Please describe this Pull Request in as much detail as possible:
Describe what the _old behaviour_ was, and what the _new behaviour_ is.

#### People who contributed to this change:
