/*
 * velocity-animate (C) 2014-2018 Julian Shapiro.
 *
 * Licensed under the MIT license. See LICENSE file in the project root for details.
 */

// Typedefs
import {SequenceList} from "../../velocity.d";

export const SequencesObject: {[name: string]: SequenceList} = {};
